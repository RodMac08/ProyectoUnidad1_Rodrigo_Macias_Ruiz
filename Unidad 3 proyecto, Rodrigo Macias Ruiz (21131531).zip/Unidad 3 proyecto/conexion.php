<?php
    $conex = mysqli_connect("localhost", "id21441003_rodrigomacias08", "Mara081103*", "id21441003_cine");
?>