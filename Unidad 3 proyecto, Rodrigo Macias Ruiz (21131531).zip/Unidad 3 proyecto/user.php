<?php
 $conexion = new mysqli("localhost", "id21441003_rodrigomacias08", "Mara081103*", "id21441003_cine");
?>